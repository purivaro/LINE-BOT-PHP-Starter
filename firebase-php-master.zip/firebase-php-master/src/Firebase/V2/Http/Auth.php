<?php

namespace Firebase\V2\Http;

interface Auth extends \Firebase\Http\Auth
{
}
