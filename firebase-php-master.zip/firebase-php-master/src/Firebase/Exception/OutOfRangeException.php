<?php

namespace Firebase\Exception;

class OutOfRangeException extends \OutOfRangeException implements FirebaseException
{
}
