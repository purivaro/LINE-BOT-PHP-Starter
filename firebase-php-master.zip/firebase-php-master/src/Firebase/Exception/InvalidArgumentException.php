<?php

namespace Firebase\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements FirebaseException
{
}
