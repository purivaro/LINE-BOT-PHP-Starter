<?php

namespace Firebase\Exception;

interface FirebaseException extends \Throwable
{
}
