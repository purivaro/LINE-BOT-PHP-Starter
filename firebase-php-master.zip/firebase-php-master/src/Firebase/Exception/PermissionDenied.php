<?php

namespace Firebase\Exception;

class PermissionDenied extends ApiException
{
}
