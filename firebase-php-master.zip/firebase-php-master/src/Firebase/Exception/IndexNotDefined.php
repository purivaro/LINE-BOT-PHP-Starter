<?php

namespace Firebase\Exception;

class IndexNotDefined extends QueryException
{
}
