<?php

namespace Firebase\Database\Query;

interface Sorter extends Modifier
{
}
