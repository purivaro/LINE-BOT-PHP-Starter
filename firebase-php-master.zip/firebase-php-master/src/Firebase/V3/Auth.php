<?php

namespace Firebase\V3;

interface Auth extends \Firebase\Http\Auth
{
}
